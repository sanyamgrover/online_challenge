import json
import requests
import boto3

def lambda_handler(event, context):
    
    a = urllib.request.urlopen('http://169.254.169.254/latest/meta-data/i-0fe150c437ebc0d30').text
    instanceid = urllib.request.urlopen('http://169.254.169.254/latest/meta-data/i-0fe150c437ebc0d30').read().decode()
	
	return(a)
	return(instanceid)

    

